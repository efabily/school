<?php
/**
 */
class CamelCaseTable extends Doctrine_Table
{

}