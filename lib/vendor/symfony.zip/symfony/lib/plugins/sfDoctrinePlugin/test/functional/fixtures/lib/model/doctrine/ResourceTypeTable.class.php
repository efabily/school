<?php

class ResourceTypeTable extends Doctrine_Table
{
}
