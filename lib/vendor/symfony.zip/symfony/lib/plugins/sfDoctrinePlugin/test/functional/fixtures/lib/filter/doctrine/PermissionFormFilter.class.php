<?php

/**
 * Permission filter form.
 *
 * @package    filters
 * @subpackage Permission *
 * @version    SVN: $Id: PermissionFormFilter.class.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class PermissionFormFilter extends BasePermissionFormFilter
{
  public function configure()
  {
  }
}