<?php

/**
 * PluginSetting form.
 *
 * @package    ##PROJECT_NAME##
 * @subpackage form
 * @author     ##AUTHOR_NAME##
 * @version    SVN: $Id: PluginSettingForm.class.php 28974 2010-04-04 22:59:54Z Kris.Wallsmith $
 */
abstract class PluginSettingForm extends BaseSettingForm
{
}
