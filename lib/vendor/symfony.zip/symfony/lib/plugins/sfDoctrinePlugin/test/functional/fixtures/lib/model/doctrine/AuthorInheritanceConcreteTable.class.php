<?php
/**
 */
class AuthorInheritanceConcreteTable extends AuthorTable
{

}