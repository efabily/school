<?php
/**
 */
class FormGeneratorTestTable extends Doctrine_Table
{

}