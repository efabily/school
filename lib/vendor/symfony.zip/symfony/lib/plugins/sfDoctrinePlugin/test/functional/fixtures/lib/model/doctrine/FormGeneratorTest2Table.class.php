<?php
/**
 */
class FormGeneratorTest2Table extends Doctrine_Table
{

}