<?php

class ModelFromLinkedSchemaTable extends Doctrine_Table
{
}
