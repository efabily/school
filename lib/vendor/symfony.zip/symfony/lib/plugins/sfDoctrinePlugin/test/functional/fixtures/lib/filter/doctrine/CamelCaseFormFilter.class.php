<?php

/**
 * CamelCase filter form.
 *
 * @package    filters
 * @subpackage CamelCase *
 * @version    SVN: $Id: CamelCaseFormFilter.class.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class CamelCaseFormFilter extends BaseCamelCaseFormFilter
{
  public function configure()
  {
  }
}