<?php

/**
 * PluginSetting form.
 *
 * @package    ##PROJECT_NAME##
 * @subpackage filter
 * @author     ##AUTHOR_NAME##
 * @version    SVN: $Id: PluginSettingFormFilter.class.php 28974 2010-04-04 22:59:54Z Kris.Wallsmith $
 */
abstract class PluginSettingFormFilter extends BaseSettingFormFilter
{
}
