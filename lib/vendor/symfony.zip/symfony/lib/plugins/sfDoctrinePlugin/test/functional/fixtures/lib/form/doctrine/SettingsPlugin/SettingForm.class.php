<?php

/**
 * Setting form.
 *
 * @package    symfony12
 * @subpackage form
 * @author     Your name here
 * @version    SVN: $Id: SettingForm.class.php 28974 2010-04-04 22:59:54Z Kris.Wallsmith $
 */
class SettingForm extends PluginSettingForm
{
  public function configure()
  {
  }
}
