<?php

class BlogAuthorTable extends AuthorTable
{
}
