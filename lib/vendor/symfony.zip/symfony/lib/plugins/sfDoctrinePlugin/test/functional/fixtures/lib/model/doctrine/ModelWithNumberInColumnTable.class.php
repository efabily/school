<?php

class ModelWithNumberInColumnTable extends Doctrine_Table
{
}
