<?php

class FormGeneratorTest3Table extends Doctrine_Table
{
}
