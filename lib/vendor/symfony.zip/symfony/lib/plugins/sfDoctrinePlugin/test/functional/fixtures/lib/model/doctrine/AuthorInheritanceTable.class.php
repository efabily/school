<?php
/**
 */
class AuthorInheritanceTable extends AuthorTable
{

}