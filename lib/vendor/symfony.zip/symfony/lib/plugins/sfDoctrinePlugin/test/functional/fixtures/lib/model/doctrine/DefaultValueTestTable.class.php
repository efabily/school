<?php
/**
 */
class DefaultValueTestTable extends Doctrine_Table
{

}