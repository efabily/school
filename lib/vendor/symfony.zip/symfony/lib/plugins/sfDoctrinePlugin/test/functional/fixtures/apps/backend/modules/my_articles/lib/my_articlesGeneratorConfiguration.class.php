<?php

/**
 * my_articles module configuration.
 *
 * @package    symfony12
 * @subpackage my_articles
 * @author     Your name here
 * @version    SVN: $Id: my_articlesGeneratorConfiguration.class.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class my_articlesGeneratorConfiguration extends BaseMy_articlesGeneratorConfiguration
{
}
