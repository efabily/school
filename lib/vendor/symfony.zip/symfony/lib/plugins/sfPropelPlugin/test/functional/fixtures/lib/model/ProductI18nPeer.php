<?php

/**
 * Subclass for performing query and update operations on the 'product_i18n' table.
 *
 * 
 *
 * @package    lib.model
 * @subpackage model
 */
class ProductI18nPeer extends BaseProductI18nPeer
{
}
