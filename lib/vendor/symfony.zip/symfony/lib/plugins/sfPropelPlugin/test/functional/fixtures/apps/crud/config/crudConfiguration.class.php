<?php

class crudConfiguration extends sfApplicationConfiguration
{
  public function configure()
  {
  }
}
