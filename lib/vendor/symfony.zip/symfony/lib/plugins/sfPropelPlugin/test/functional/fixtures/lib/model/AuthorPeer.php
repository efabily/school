<?php

/**
 * Subclass for performing query and update operations on the 'author' table.
 *
 * 
 *
 * @package lib.model
 */ 
class AuthorPeer extends BaseAuthorPeer
{
}
