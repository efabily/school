<?php

/**
 * ProductI18n form.
 *
 * @package    form
 * @subpackage product_i18n
 * @version    SVN: $Id: ProductI18nForm.class.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class ProductI18nForm extends BaseProductI18nForm
{
  public function configure()
  {
  }
}
