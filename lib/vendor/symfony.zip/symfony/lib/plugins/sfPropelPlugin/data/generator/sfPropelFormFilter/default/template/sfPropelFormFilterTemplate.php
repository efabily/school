[?php

/**
 * <?php echo $this->table->getClassname() ?> filter form.
 *
 * @package    ##PROJECT_NAME##
 * @subpackage filter
 * @author     ##AUTHOR_NAME##
 */
class <?php echo $this->table->getClassname() ?>FormFilter extends Base<?php echo $this->table->getClassname() ?>FormFilter
{
  public function configure()
  {
  }
}
