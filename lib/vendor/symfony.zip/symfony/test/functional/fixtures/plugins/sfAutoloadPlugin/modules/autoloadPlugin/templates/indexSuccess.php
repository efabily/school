<div id="lib1"><?php echo $lib1 ?></div>
<div id="lib2"><?php echo $lib2 ?></div>
<div id="lib3"><?php echo $lib3 ?></div>
